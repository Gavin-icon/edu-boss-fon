<template>
  <edit-or-create-resource></edit-or-create-resource>
</template>

<script>
import EditOrCreateResource from './components/EditOrCreateResource.vue'
export default {
  name: 'CreateResource',
  components: {
    EditOrCreateResource
  }
}
</script>

<style lang="scss" scoped></style>
