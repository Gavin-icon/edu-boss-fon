<template>
  <div class="add-advert-space">
    <add-or-edit-advert-space></add-or-edit-advert-space>
  </div>
</template>

<script>
import AddOrEditAdvertSpace from './components/addOrEditAdvertSpace.vue'
export default {
  name: 'AddAdvertSpace',
  components: {
    AddOrEditAdvertSpace
  }
}
</script>

<style lang="scss" scoped>

</style>
